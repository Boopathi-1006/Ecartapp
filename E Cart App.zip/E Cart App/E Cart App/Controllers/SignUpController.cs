﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using E_Cart_App.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;
using System.Text;
namespace E_Cart_App.Controllers
{
    public class SignUpController : Controller
    {
        //
        // GET: /SignUp/
        public ActionResult SignUp()
        {
            UserLogin ul = new UserLogin();
            return View(ul);
        }
        [HttpPost]
        public ActionResult SignUp(UserLogin user)
        {
            MD5CryptoServiceProvider md5Hasher = new MD5CryptoServiceProvider();
            UTF8Encoding encoder = new UTF8Encoding();
            byte[] hashedBytes = md5Hasher.ComputeHash(encoder.GetBytes(user.password));

            string constr = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "INSERT INTO Temp_userdetails(username,password,Mobileno,Emailid) VALUES(@username,@password,@Mobileno,@Emailid)";
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    cmd.Parameters.AddWithValue("@username", user.username);
                    cmd.Parameters.AddWithValue("@password", hashedBytes);
                    cmd.Parameters.AddWithValue("@Mobileno", user.Mobileno);
                    cmd.Parameters.AddWithValue("@Emailid", user.Email);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    ViewBag.Message = "User Added Successfully";
                }
            }
            return View(user);
           
        }
        [HttpPost]
        public ActionResult Login(UserLogin user)
        {
            return RedirectToAction("Login", "Login");

        }
	}
}