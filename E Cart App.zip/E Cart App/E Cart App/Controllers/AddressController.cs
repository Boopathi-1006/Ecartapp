﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using E_Cart_App.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace E_Cart_App.Controllers
{
    public class AddressController : Controller
    {
        //
        // GET: /Address/
        public ActionResult Address()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Address(Address a)
        {
            string constr = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("temp_placeorder_devp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CustName", @Session["Username"]);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                ViewBag.Address = "Order Placed Successfully";

            }
            return View();
        }
	}
}