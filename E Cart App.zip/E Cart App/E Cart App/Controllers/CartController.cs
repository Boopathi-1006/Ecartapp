﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using E_Cart_App.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
namespace E_Cart_App.Controllers
{
    public class CartController : Controller
    {
        //
        // GET: /Cart/
        public ActionResult Cart()
        {
            List<Product> CartLst = new List<Product>();
            string CS = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("select * from temp_cart where CustName=@CustName", con);
                cmd.Parameters.AddWithValue("@CustName", @Session["Username"]);
                cmd.CommandType = CommandType.Text;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    var stat = new Product();
                    stat.Productid = Convert.ToInt32(rdr["Pk_id"]);
                    stat.Productname = rdr["Productname"].ToString();
                    stat.Image = rdr["Imagename"].ToString();
                    if (Convert.ToInt32(rdr["Prodavailability"]) != 0)
                    {
                        ViewBag.InMessage = "In stock";
                        stat.Productavailability = ViewBag.InMessage;
                    }
                    else
                    {
                        ViewBag.OutMessage = "Out of stock";
                        stat.Productavailability = ViewBag.OutMessage;
                    }
                    stat.Price = Convert.ToInt32(rdr["Prodprice"]);
                    stat.Quantity = Convert.ToInt32(rdr["Quantity"]);
                    CartLst.Add(stat);
                }
            }
            return View(CartLst);
        }
        public ActionResult Delete(int id)
        {
            string constr = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                string query = "delete from temp_cart where Productid=@Productid and CustName=@CustName";
                using (SqlCommand cmd = new SqlCommand(query))
                {
                    cmd.Connection = con;
                    con.Open();
                    cmd.Parameters.AddWithValue("@Productid", id);
                    cmd.Parameters.AddWithValue("@CustName", @Session["Username"]);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    TempData["DeleteMessage"] = "Product removed from Cart";
                }

            }
            return RedirectToAction("Cart", "Cart");

        }
        [HttpPost]
        public ActionResult Placeorder(UserLogin user)
        {
            return RedirectToAction("Address", "Address");

        }
	}
}