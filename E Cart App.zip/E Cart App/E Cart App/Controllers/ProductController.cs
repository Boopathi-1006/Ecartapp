﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using E_Cart_App.Models;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace E_Cart_App.Controllers
{
    public class ProductController : Controller
    {
        //
        // GET: /Product/
        public ActionResult Product()
        {
            List<Product> ProdLst = new List<Product>();
            string CS = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("select * from temp_product", con);
                cmd.CommandType = CommandType.Text;
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    var stat = new Product();
                    stat.Productid = Convert.ToInt32(rdr["Pk_id"]);
                    stat.Productname = rdr["Productname"].ToString();
                    stat.Image = rdr["Imagename"].ToString();
                    if(Convert.ToInt32(rdr["Prodavailability"])!=0)
                    {
                        ViewBag.InMessage = "In stock";
                        stat.Productavailability = ViewBag.InMessage;
                    }
                    else
                    {
                        ViewBag.OutMessage = "Out of stock";
                        stat.Productavailability = ViewBag.OutMessage;
                    }
                    stat.Price = Convert.ToInt32(rdr["Prodprice"]);
                    ProdLst.Add(stat);
                    
                }
            }
            return View(ProdLst);
        }
        public ActionResult Addcart(int id,string image,string productname,decimal price)
        {
            string constr = ConfigurationManager.ConnectionStrings["mydb"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                SqlCommand cmd = new SqlCommand("temp_addcart_devp", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@CustName", @Session["Username"]);
                cmd.Parameters.AddWithValue("@Productid", id);
                cmd.Parameters.AddWithValue("@Imagename", image);
                cmd.Parameters.AddWithValue("@Productname", productname);
                cmd.Parameters.AddWithValue("@Prodprice", price);
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
                TempData["AlertMessage"] = "Product added in Cart";

            }
            return RedirectToAction("Product", "Product"); 

        }
	}
}