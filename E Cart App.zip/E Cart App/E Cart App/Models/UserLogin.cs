﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace E_Cart_App.Models
{
    public class UserLogin
    {
        [Required(ErrorMessage = "Userid field is required.")]
        [MaxLength(30)]
        [DisplayName("User Name")]
        public string username { get; set; }
        [Required(ErrorMessage = "Password field is required")]
        [DisplayName("Password")]
        [DataType(DataType.Password)]
        public string password { get; set; }
        [Required(ErrorMessage = "Confirm Password field is required")]
        [DataType(DataType.Password)]
        [DisplayName("Confirm Password")]
        [Compare("password")]
        public string confirmpassword { get; set; }
        [Required(ErrorMessage = "Mobile Number field is required")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Mobile Number.")]
        [DisplayName("Mobile Number")]
        public long Mobileno { get; set; }
        [Display(Name = "Email address")]
        [Required(ErrorMessage = "The email address is required")]
        [EmailAddress(ErrorMessage = "Invalid Email Address")]
        public string Email { get; set; }
    }
}