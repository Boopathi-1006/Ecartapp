﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace E_Cart_App.Models
{
    public class Address
    {
        [Required(ErrorMessage = "First Name field is required.")]
        [DisplayName("First Name")]
        public string FirstName { get; set; }
        [DisplayName("Last Name")]
        public string Lastname { get; set; }
        [Required(ErrorMessage = "Address field is required")]
        [DisplayName("Address")]
        public string CustAddress { get; set; }
        [Required(ErrorMessage = "City field is required")]
        [DisplayName("City")]
        public string City { get; set; }
        [Required(ErrorMessage = "State field is required")]
        [DisplayName("State Name")]
        public string state { get; set; }
        [DisplayName("Pin Code")]
        public int pincode { get; set; }
        [Required(ErrorMessage = "Mobile Number field is required")]
        [RegularExpression(@"^([0-9]{10})$", ErrorMessage = "Invalid Mobile Number.")]
        [DisplayName("Mobile Number")]
        public long Mobileno { get; set; }
        [Display(Name = "Payment Mode")]
        public string Paymentmode { get; set; }
    }
}