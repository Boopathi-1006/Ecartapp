﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace E_Cart_App.Models
{
    public class Product
    {
        [DisplayName("Product ID")]
        public int Productid { get; set; }
        [DisplayName("Product Image")]
        public string Image { get; set; }
        [DisplayName("Product Name")]
        public string Productname { get; set; }
        [DisplayName("Price")]
        public decimal Price { get; set; }
        [DisplayName("Quanity")]
        public int Quantity { get; set; }
        [DisplayName("Product Status")]
        public string Productavailability { get; set; }
        [DisplayName("Order Status")]
        public string Orderstatus { get; set; }

    }
}