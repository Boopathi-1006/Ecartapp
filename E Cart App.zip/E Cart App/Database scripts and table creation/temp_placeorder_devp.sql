create or alter proc temp_placeorder_devp (@custname varchar(50))
as
Begin

insert into temp_Myorder(CustName,Productid,Imagename,Productname,Prodprice,Quantity)
select CustName,Productid,Imagename,Productname,Prodprice,Quantity from temp_cart where CustName=@custname

delete from temp_cart where CustName=@custname

End