create or alter proc temp_userlogin_devp (@username varchar(50),@password binary(16))
as
begin

if exists(select * from Temp_userdetails where Username=@username and password=@password)
Begin

select 'Success' as Msgtype

End
else
begin 

select 'Error' as Msgtype

end

end