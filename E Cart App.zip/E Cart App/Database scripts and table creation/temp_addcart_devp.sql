create or alter proc temp_addcart_devp (@CustName varchar(50),@Productid int,@Imagename varchar(100),@Productname varchar(100),@Prodprice numeric(12,2))
as
begin
if exists(select * from temp_cart where CustName=@CustName and Productid=@Productid)
begin
update temp_cart set Quantity=Quantity+1,Prodprice=Prodprice+Prodprice where CustName=@CustName and Productid=@Productid
update temp_product set Prodavailability=Prodavailability-1 where Pk_id=@Productid
update a set a.Prodavailability=b.Prodavailability from temp_cart a join temp_product b on b.Pk_id=a.productid where b.Pk_id=@Productid
end
else
begin
INSERT INTO temp_cart(CustName,Productid,Imagename,Productname,Prodprice) VALUES(@CustName,@Productid,@Imagename,@Productname,@Prodprice)
update temp_product set Prodavailability=Prodavailability-1 where Pk_id=@Productid
update a set a.Prodavailability=b.Prodavailability from temp_cart a join temp_product b on b.Pk_id=a.productid where b.Pk_id=@Productid
end
end


