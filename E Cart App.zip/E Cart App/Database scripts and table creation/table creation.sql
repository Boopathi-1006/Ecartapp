
drop table Temp_userdetails
create table Temp_userdetails (Pk_id int identity(1,1),Username varchar(50) primary key,password binary(16), Mobileno bigint,Emailid varchar(100))
select * from Temp_userdetails

--exec temp_userlogin_devp @username=N'Boopathi',@password=0x2B8AB83CA6EAC4B631FD4C86847361A1
--select * from Temp_userdetails where Username='Boopathi' and password=0x2B8AB83CA6EAC4B631FD4C86847361A1


drop table temp_product
create table temp_product (Pk_id int identity(1,1),Imagename varchar(100),Productname varchar(100),Prodavailability int,Prodprice numeric(12,2))
insert into temp_product values ('Canon EOS 1500D 24.1 Digital SLR Camera.png','Canon EOS 1500D 24.1 Digital SLR Camera',5,35000),
('Oppo Reno4 Pro.png','Oppo Reno4 Pro',5,18000),
('Redmi 9 Prime.png','Redmi 9 Prime',5,14000),
('Samsung Galaxy M31.png','Samsung Galaxy M31',5,10000)
select * from temp_product
drop table temp_cart
create table temp_cart (Pk_id int identity(1,1),CustName varchar(50),Productid int,Imagename varchar(100),Productname varchar(100),Prodprice numeric(12,2),Quantity int default 1,Prodavailability int)

select * from temp_cart

drop table temp_Myorder
create table temp_Myorder(Pk_id int identity(1,1),CustName varchar(50),Productid int,Imagename varchar(100),Productname varchar(100),Prodprice numeric(12,2),
Quantity int)
select * from temp_Myorder





